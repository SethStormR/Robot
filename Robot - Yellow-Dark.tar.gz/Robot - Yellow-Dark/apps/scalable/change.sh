for x in $*
do
sed -e "s/#cabab4/#f7e062/g" $x > temp$x
mv temp$x $x
done
